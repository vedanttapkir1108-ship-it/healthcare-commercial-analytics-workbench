# Responsible Commercial Analytics Workbench — IQVIA portfolio project

## Purpose
A reproducible, public-data research prototype showing how an analyst could turn IQVIA's published market evidence into a transparent prioritization and insight workflow. It is **not** an IQVIA product, and it uses no confidential, patient-level, employee, or proprietary IQVIA data.

## Why this problem
IQVIA's public materials emphasize commercial analytics, sales-force effectiveness, precise HCP targeting, data access, AI/ML, and trustworthy/defensible AI. Public filings also identify data access restrictions, privacy/security, data quality, rapid AI change, and the need to process increasing volumes of data as business risks.

## Public source data
The included CSV transcribes selected headline metrics from IQVIA pages/reports. Every row includes a source label. The underlying source URLs are recorded below:

- https://www.iqvia.com/-/media/iqvia/pdfs/events/presentation_global-meds-webinar_public.pdf
- https://www.iqvia.com/insights/the-iqvia-institute/reports-and-publications/reports/global-oncology-trends-2025
- https://www.iqvia.com/blogs/2026/03/iqvia-early-bird-2025-revealed
- https://www.sec.gov/Archives/edgar/data/1478242/000162828026008322/iqv-20251231.htm
- https://www.iqvia.com/solutions/commercialization/commercial-analytics/create-a-winning-hcp-promotion-strategy-and-drive-sales

## Run
```bash
python src/analyze.py
```
Outputs: `reports/oncology_spending.png`, `reports/therapy_concentration.png`, `reports/derived_metrics.csv`, and `reports/executive_summary.md`.

## Recommended phase 2
Use only synthetic or licensed data to add HCP segmentation, promotion-response modelling, scenario simulation, dashboard filters, and a GenAI explanation layer with an audit trail. Never scrape private employee information or expose personal/health data.
